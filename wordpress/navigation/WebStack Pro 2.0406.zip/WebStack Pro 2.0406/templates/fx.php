<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
                <div class="background-fx">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-01.svg') ?>" class="shape-01">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-02.svg') ?>" class="shape-02">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-03.svg') ?>" class="shape-03">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-04.svg') ?>" class="shape-04">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-05.svg') ?>" class="shape-05">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-06.svg') ?>" class="shape-06">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-07.svg') ?>" class="shape-07">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-08.svg') ?>" class="shape-08">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-09.svg') ?>" class="shape-09">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-10.svg') ?>" class="shape-10">
                    <img src="<?php echo get_theme_file_uri('/images/fx/shape-11.svg') ?>" class="shape-11">
                </div>